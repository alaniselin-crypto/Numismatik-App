const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CZVaEU_8.js","./index-wEe0HNj_.js","./index-By-NWg6V.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-wEe0HNj_.js";const _=r("Share",{web:()=>t(()=>import("./web-CZVaEU_8.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
