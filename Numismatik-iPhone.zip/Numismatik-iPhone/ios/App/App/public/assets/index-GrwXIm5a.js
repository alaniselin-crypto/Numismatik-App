const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CNfAG7Hb.js","./index--eRABy4P.js","./index-DbJr7jf3.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index--eRABy4P.js";const _=r("Share",{web:()=>t(()=>import("./web-CNfAG7Hb.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
