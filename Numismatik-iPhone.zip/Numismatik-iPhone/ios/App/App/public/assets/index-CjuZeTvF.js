const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BAjajZce.js","./index-D_CcsXy1.js","./index-CBRD4vfr.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-D_CcsXy1.js";const _=r("Share",{web:()=>t(()=>import("./web-BAjajZce.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
