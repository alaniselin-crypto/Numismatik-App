const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Tl7xBRkG.js","./index-B53QvwXk.js","./index-UVTJSc_y.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-B53QvwXk.js";const _=r("Share",{web:()=>t(()=>import("./web-Tl7xBRkG.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
