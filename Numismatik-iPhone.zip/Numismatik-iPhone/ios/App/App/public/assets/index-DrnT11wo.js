const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BYSWz0nR.js","./index-Dd7nX1c6.js","./index-CtaFsiOH.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Dd7nX1c6.js";const _=r("Share",{web:()=>t(()=>import("./web-BYSWz0nR.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
