const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BVCDtR5l.js","./index-DdtfVx6_.js","./index-Bx8dEGUn.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DdtfVx6_.js";const _=r("Share",{web:()=>t(()=>import("./web-BVCDtR5l.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
