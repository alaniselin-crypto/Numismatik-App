const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-26Y00Vl7.js","./index-DAE49wyG.js","./index-CVbdIG8M.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DAE49wyG.js";const _=r("Share",{web:()=>t(()=>import("./web-26Y00Vl7.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
