const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-B5njl4mk.js","./index-Bh2hUwiM.js","./index-CVbdIG8M.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Bh2hUwiM.js";const _=r("Share",{web:()=>t(()=>import("./web-B5njl4mk.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
