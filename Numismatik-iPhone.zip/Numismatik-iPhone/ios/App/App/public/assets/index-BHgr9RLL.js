const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-c4D4KRIT.js","./index-BM4ThOo7.js","./index-DbJr7jf3.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BM4ThOo7.js";const _=r("Share",{web:()=>t(()=>import("./web-c4D4KRIT.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
