const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BWyyu4vF.js","./index-B9U0AFBg.js","./index-DbJr7jf3.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-B9U0AFBg.js";const _=r("Share",{web:()=>t(()=>import("./web-BWyyu4vF.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
