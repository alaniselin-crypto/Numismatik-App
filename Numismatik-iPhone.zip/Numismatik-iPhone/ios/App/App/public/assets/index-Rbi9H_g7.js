const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Dl92YJS6.js","./index-CKDEd-ic.js","./index-Bsl_FzLJ.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CKDEd-ic.js";const _=r("Share",{web:()=>t(()=>import("./web-Dl92YJS6.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
