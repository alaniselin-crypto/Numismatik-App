const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CKxxCi1-.js","./index-TQSofSpF.js","./index-BxMY4ThT.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-TQSofSpF.js";const _=r("Share",{web:()=>t(()=>import("./web-CKxxCi1-.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
