const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BsrTLDDg.js","./index-CT1-j2Zk.js","./index-D8uFwrqx.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CT1-j2Zk.js";const _=r("Share",{web:()=>t(()=>import("./web-BsrTLDDg.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
