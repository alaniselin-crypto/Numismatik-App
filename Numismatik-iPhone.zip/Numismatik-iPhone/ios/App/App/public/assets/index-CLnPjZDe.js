const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DrcMxTf4.js","./index-BouKOdWL.js","./index-CVbdIG8M.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BouKOdWL.js";const _=r("Share",{web:()=>t(()=>import("./web-DrcMxTf4.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
