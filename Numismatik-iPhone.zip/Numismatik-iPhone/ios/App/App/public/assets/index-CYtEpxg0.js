const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BVHLuds8.js","./index-ge-tsPnl.js","./index-CVbdIG8M.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-ge-tsPnl.js";const _=r("Share",{web:()=>t(()=>import("./web-BVHLuds8.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
