const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BUufT52F.js","./index-nF2dvWaW.js","./index-UY13QYP7.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-nF2dvWaW.js";const _=r("Share",{web:()=>t(()=>import("./web-BUufT52F.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
