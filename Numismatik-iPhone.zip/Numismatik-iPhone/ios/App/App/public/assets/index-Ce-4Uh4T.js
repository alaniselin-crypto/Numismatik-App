const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Dg3hhZQ5.js","./index-Dy2W-zgP.js","./index-Bx8dEGUn.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Dy2W-zgP.js";const _=r("Share",{web:()=>t(()=>import("./web-Dg3hhZQ5.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
