const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DAUVIcoR.js","./index-CZ0urEUF.js","./index-BMO-E8_9.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CZ0urEUF.js";const _=r("Share",{web:()=>t(()=>import("./web-DAUVIcoR.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
