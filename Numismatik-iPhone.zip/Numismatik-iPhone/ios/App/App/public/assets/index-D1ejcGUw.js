const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DgTm7i4h.js","./index-P6xu2-Sd.js","./index-fj2L9jrF.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-P6xu2-Sd.js";const _=r("Share",{web:()=>t(()=>import("./web-DgTm7i4h.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
