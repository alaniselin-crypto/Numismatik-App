const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-0Duv0NCW.js","./index-DU2ni7hO.js","./index-AMZT8YnQ.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DU2ni7hO.js";const _=r("Share",{web:()=>t(()=>import("./web-0Duv0NCW.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
