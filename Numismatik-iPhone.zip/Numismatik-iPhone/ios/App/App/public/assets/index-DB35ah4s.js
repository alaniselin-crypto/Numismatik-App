const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DusLL8N3.js","./index-DN3NRN6F.js","./index-CbhSDKWe.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DN3NRN6F.js";const _=r("Share",{web:()=>t(()=>import("./web-DusLL8N3.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
