const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-rsFp-ZO3.js","./index-CFjqnXcs.js","./index-DGLPC5IG.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CFjqnXcs.js";const _=r("Share",{web:()=>t(()=>import("./web-rsFp-ZO3.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
