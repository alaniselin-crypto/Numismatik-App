const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-P3xd_0FN.js","./index-s4L6J-D-.js","./index-C1tyV7xV.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-s4L6J-D-.js";const _=r("Share",{web:()=>t(()=>import("./web-P3xd_0FN.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
