const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CnkcNPsx.js","./index-CyQXMlR9.js","./index-CbhSDKWe.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CyQXMlR9.js";const _=r("Share",{web:()=>t(()=>import("./web-CnkcNPsx.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
