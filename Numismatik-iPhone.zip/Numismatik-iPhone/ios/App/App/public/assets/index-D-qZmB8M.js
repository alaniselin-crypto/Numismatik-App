const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BIpJALnu.js","./index-Yeyazv8W.js","./index-BBZRKoCu.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Yeyazv8W.js";const _=r("Share",{web:()=>t(()=>import("./web-BIpJALnu.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
