const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BoKT_Eux.js","./index-KB0bMtd0.js","./index-CLHF8yZ4.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-KB0bMtd0.js";const _=r("Share",{web:()=>t(()=>import("./web-BoKT_Eux.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
